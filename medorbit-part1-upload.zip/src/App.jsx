import React from 'react'
import {Phone,MessageCircle,GraduationCap,Globe2,BriefcaseBusiness,Stethoscope,ArrowRight} from 'lucide-react'

const whatsapp='https://wa.me/919142102309?text=Hello%20MedOrbit%2C%20I%20need%20guidance.'
const cards=[
['MBBS India',Stethoscope,'Admission guidance for government, private and deemed universities.'],
['MBBS Abroad',Globe2,'Explore Nepal, Georgia, Russia, Kazakhstan and more.'],
['Engineering',GraduationCap,'College selection, applications and counselling support.'],
['Career & Jobs',BriefcaseBusiness,'Vacancy updates, profile guidance and application support.']
]

export default function App(){
return <div>
<header><div className="wrap nav"><div className="brand"><b>M</b><span>MedOrbit</span></div><nav><a href="#home">Home</a><a href="#courses">Courses</a><a href="#countries">Countries</a><a href="#contact">Contact</a></nav><a className="btn small" href={whatsapp}>Free Counselling</a></div></header>

<section id="home" className="hero"><div className="wrap grid">
<div><span className="tag">Education • Career • Success</span><h1>Your trusted path to the right college and career.</h1><p>Personalised counselling for MBBS, engineering, MBA, study abroad and job opportunities.</p><div className="actions"><a className="btn" href={whatsapp}>Get Free Counselling <ArrowRight size={18}/></a><a className="btn outline" href="#courses">Explore Courses</a></div></div>
<div className="visual"><Globe2 size={95}/><span className="pill p1">MBBS India</span><span className="pill p2">Study Abroad</span><span className="pill p3">Career Jobs</span></div>
</div></section>

<section id="courses" className="section"><div className="wrap"><span className="tag">Popular Choices</span><h2>Explore courses with expert guidance</h2><div className="cards">{cards.map(([t,I,d])=><article><I/><h3>{t}</h3><p>{d}</p><a href="#contact">Learn more →</a></article>)}</div></div></section>

<section id="countries" className="section light"><div className="wrap"><span className="tag">Study Destinations</span><h2>Choose the right country</h2><div className="countries">{['India','Nepal','Georgia','Russia','Kazakhstan','Kyrgyzstan','Uzbekistan','Bangladesh'].map(x=><div>{x}</div>)}</div></div></section>

<section className="section dark"><div className="wrap cta"><div><span className="tag gold">Career Portal</span><h2>Find healthcare, aviation and corporate opportunities.</h2></div><a className="btn goldbtn" href={whatsapp}>Enquire on WhatsApp</a></div></section>

<section id="contact" className="section"><div className="wrap contact"><div><span className="tag">Contact MedOrbit</span><h2>Start your counselling today</h2><p>Wave Silver Tower 7006, 7th Floor, Sector 18, Noida, Uttar Pradesh</p><p><Phone size={18}/> +91 9142102309</p></div><div className="form"><input placeholder="Full name"/><input placeholder="Phone number"/><select><option>Select interest</option><option>MBBS India</option><option>MBBS Abroad</option><option>Engineering</option><option>Jobs</option></select><textarea placeholder="Your message"></textarea><a className="btn" href={whatsapp}>Submit Enquiry</a></div></div></section>

<footer><div className="wrap foot"><div className="brand"><b>M</b><span>MedOrbit</span></div><p>Education • Career • Success</p><p>medorbits.in • +91 9142102309</p></div></footer>

<div className="mobilebar"><a href="tel:+919142102309"><Phone size={18}/>Call</a><a href={whatsapp}><MessageCircle size={18}/>WhatsApp</a></div>
</div>
}
